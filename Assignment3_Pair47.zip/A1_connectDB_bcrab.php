<?php
// A1_connectDB_bcrab.php for bcrab
/*
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "bnbu";
*/ 
$servername = "wsdb.bnbu.edu.cn";
$username = "1002pair47"; // change XXXXX to your bcrab username
$password = "EPW8AbGN6"; // change XXXXX to your bcrab password
$dbname = "1002pair47"; // change to your own db name


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Error: " . $conn->connect_error);
}/*else{
    echo "Connected successfully!";
}*/

?>