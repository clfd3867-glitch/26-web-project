<?php

// include "B_FoodSurveyForm.php";
include "A1_connectDB_bcrab.php";

$restaurant = $_POST['restaurant'];

echo "You selected $restaurant.<br> Thank you for telling us.<br><br>";

// Read values from favoritemeal table.  
$sql = "SELECT * FROM `FavoriteMeal` WHERE `restaurant` = '$restaurant'";
// Need '' for $

$result = mysqli_query($conn, $sql);
// Also can be: $result = $conn->query($sql);

if (mysqli_num_rows($result) > 0) {
    //get number of columns
	$fields = mysqli_num_fields($result);

    //Get each row data
	$numrows = mysqli_num_rows($result);
	if ($numrows != 1) {
		echo "Warning: number of rows $numrows is not 1.<br>";
	}
	
    while ($row=mysqli_fetch_array($result)){	// should only be 1 row.
		
		$votes = (int)$row[2] + 1;	//increment votes for the selected restaurant.

	}
} else {
	echo "$restaurant is not in table favoritemeal";
}

// Do another SQL to update the votes in the database. 
$sql = "UPDATE `FavoriteMeal` SET `votes` = $votes WHERE `restaurant` = '$restaurant'";
$result = mysqli_query($conn, $sql);

if ($result<=0) {
	echo "<script> alert('update failed.') </script> ";			
} else {
	echo "$restaurant now has $votes votes <br>";
}

// Do another SQL to print the updated table
$sql = "SELECT * FROM `FavoriteMeal`";
// bcrab is case-sensitive
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row

    echo "<h2>Current Votes </h2>";
    echo "<table border='1'>";

	//print the heading of table
    echo "<tr>";
    //print each column name
    while ($property = mysqli_fetch_field($result)) {
        echo "<th>".$property->name."</th>";
    }
    echo "</tr>";

    //get number of columns
	$fields = mysqli_num_fields($result);

    //Get data of each row
    while ($row=mysqli_fetch_array($result)){
        echo "<tr>";
        for ($f=0; $f < $fields; $f++) {           
            echo "<td>".$row[$f]."</td>"; 
        }
        echo "</tr>";
    }

    echo "</table> <br>";

} else {
	echo "0 results <br>";
}

echo "Go back to <a href='B_FoodSurveyForm.php'> Food Survey Form </a>";

mysqli_close($conn);
?>