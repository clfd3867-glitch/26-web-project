<?php
// A1_connectDB.php for XAMPP
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "bnbu";
// For localhost 
// Names after $
/*
$servername = "localhost"; // if use uic server, change to db.bcrab.cn
$username 	= "root";  // change to your account
$password 	= "";	  // change to your account
$db		    = "bnbu";	  // change to your database name
// for public localhost (no password)
*/

$conn = new mysqli($servername, $username, $password, $dbname);
// Create connection
// new mysqli(): Object

if ($conn->connect_error) {
    die("Error: " . $conn->connect_error);
    // $conn->connect_error print specific error
}/*else{
    echo "Connected successfully!";
}*/

?>