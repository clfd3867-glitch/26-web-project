<!DOCTYPE html>
<html>
<body>

<h2>Meals Survey Form</h2>

<form action="B_FoodSurvey.php" method="POST">
  <h3>Where do you get your favorite meal in BNBU?</h3>
  <input type="radio" name="restaurant" value="Happy Meal">
    <label for="html">Happy Meal</label><br>
  <input type="radio" name="restaurant" value="Zhuo Building">
    <label for="html">Zhuo Building</label><br>
  <input type="radio" name="restaurant" value="Admin Building">
    <label for="html">Admin Building</label><br>
  <input type="radio" name="restaurant" value="Other BNBU">
    <label for="html">Other BNBU restaurant</label><br>
  <input type="radio" name="restaurant" value="Takeout Outside">
    <label for="html">Takeout from outside</label><br><br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>
