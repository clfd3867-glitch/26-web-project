<?php

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "bnbu";

/*
$servername = "localhost"; // if use uic server, change to db.bcrab.cn
$username 	= "root";  // change to your account
$password 	= "";	  // change to your account
$db		    = "bnbu";	  // change to your database name
*/

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error: " . $conn->connect_error);
}

?>