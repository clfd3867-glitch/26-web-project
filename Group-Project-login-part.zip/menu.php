<!DOCTYPE html>

<div id="menu">
    <a href="login.php">Login/Register</a>
    <a href="clothes.php">Clothes</a>
    <a href="neces.php">Necessities</a>
    <a href="orna.php">Ornaments</a>
</div>
