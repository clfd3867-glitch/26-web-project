
<?php
    /* https://www.w3schools.com/php/php_sessions.asp */
    session_start();
    $_SESSION["login"] = "";

    include 'connectDB.php';

    /* https://www.w3schools.com/php/php_form_validation.asp */
    $name = $email = $gender = $comment = $website = "";
    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["loginSubmit"])) {
        $username = test_input($_POST["username"]);
        $password = test_input($_POST["password"]);
        login($conn, $username, $password);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["registerSubmit"])) {
        $username = test_input($_POST["username"]);
        $phone = test_input($_POST["phone"]);
        $password = test_input($_POST["password"]);
        $confirmPassword = test_input($_POST["confirmPassword"]);
        /* Register case 1 */
        if ($confirmPassword != $password){
            echo "<script> alert('Confirm password and password is different!') </script>";
        }else{
            register($conn, $username, $phone, $password);
        }
    }

    /* Check submitted data existence */
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    function login($conn, $username, $password){
        $sql = "SELECT `password` FROM `members` WHERE `username` = '$username'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            if ($row["password"] != $password){
                /* Login case 1 */
                echo "<script> alert('Wrong password! Please check again.') </script>";
            }else{
                /* Login case 2: Success */
                echo "<script> alert('Successfully login! Welcome back.') </script>";
                /* Set Session */
                $_SESSION["login"] = $username;
            }
        }else{
            /* Login case 3 */
            echo "<script> alert('Inexistent username! Please check again.') </script>";
        }
    }

    function register($conn, $username, $phone, $password){
        $sql = "SELECT * FROM `members`";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0){
            /* Register case 2 [More Features (1)] */
            while ($row = mysqli_fetch_assoc($result)){
                $storedUsername = $row["username"];
                $storedPhone = $row["phone"];
                if ($storedUsername == $username && $storedPhone == $storedPhone){
                    echo "<script> alert('User already exist! Please change username or phone.') </script>";
                    return;
                }
            }
        }
        /* Register case 3: Success */
        $sql = "INSERT INTO `members` VALUES (NULL, '$username', '$password', '$phone')";
        $result = mysqli_query($conn, $sql);
        echo "<script> alert('Register successfully! Please login.') </script>";
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="format.css"/>
        <style>
        .demo-note {
            color: gray;
            font-size: 12px;
            margin-top: 10px;
            text-align: center;
        }
            
        </style>
        <title>Login/Register</title>
    </head>
    <body>
        <div id="container">
            <div id="title">Login</div>
            <?php include 'menu.php' ?>
            <div id="left">
                <h3>Login Member</h3>
                <form method="post">
                    <input type="text" name="username" placeholder="Username" required><br><br>
                    <input type="password" name="password" placeholder="Password" required><br><br>
                    <button type="submit" name="loginSubmit">Submit</button>
                </form>
            </div>
            <div id="right">
                <h3>Register New Member</h3>
                <form method="post">
                    <input type="text" name="username" placeholder="Username" required><br><br>
                    <input type="text" name="phone" placeholder="phone" required><br><br>
                    <label for="password">Password:</label><br>
                    <input type="password" name="password" id="password" placeholder="****" required><br>
                    <label for="confirmPassword">Confirm password:</label><br>
                    <input type="password" name="confirmPassword" id="confirmPassword" placeholder="****" required><br><br>
                    <button type="submit" name="registerSubmit">Submit</button>
                    <button type="reset">Reset</button>
                </form>
            </div>
        </div>
    </body>
</html>

